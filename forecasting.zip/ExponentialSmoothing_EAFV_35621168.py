'''
This code uses the Exponential Smoothing method to make time series forecasts for EAFV data.

Steps:
1. Import necessary libraries
2. Load Data
3. Preprocess and replace anomalies (only for fitting)
4. Plot Residual ACF
5. Apply Holt-Winters Triple Exponential Smoothing
6. Forecast from January 2024 to December 2025
7. Plot observed, fitted and forecasted values
8. Model Evaluation
'''

# Step 1: Import necessary libraries
import os
import pandas as pd
import matplotlib
matplotlib.use("TkAgg")

import matplotlib.pyplot as plt
import numpy as np
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.graphics.tsaplots import plot_acf
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Step 2: Load original data
os.chdir(r"C:\Users\mac\Desktop\semester 3\forecasting")
df = pd.read_excel("EAFVData35621168.xlsx")
df.columns = ["Date", "Value"]
df["Date"] = pd.to_datetime(df["Date"], format="%Y %b", errors="coerce")
df["Value"] = pd.to_numeric(df["Value"], errors="coerce")
df = df.dropna(subset=["Date", "Value"]).reset_index(drop=True)
df = df.set_index("Date").asfreq("MS")

# 👉 Step 3: Preprocess and replace anomalies (only for fitting)
df_clean = df.copy()

cutoff_anomaly = "2020-04-01"
end_pre_anomaly = "2020-03-01"
anomaly_end = "2022-02-01"

pre_anomaly = df_clean[df_clean.index <= end_pre_anomaly]
model_pre = ExponentialSmoothing(
    pre_anomaly["Value"],
    trend="add",
    seasonal="add",
    seasonal_periods=12,
    initialization_method="estimated"
).fit()

anomaly_dates = pd.date_range(start=cutoff_anomaly, end=anomaly_end, freq="MS")
forecast_anomaly = model_pre.forecast(len(anomaly_dates))
forecast_anomaly.index = anomaly_dates

# Replace outliers in the clean data (the original df remains unchanged)
df_clean.loc[forecast_anomaly.index, "Value"] = forecast_anomaly

# Step 4: Train until 2023-12
cutoff_date = "2024-01-01"
train = df_clean[df_clean.index < cutoff_date]

# Step 5: Fit Holt-Winters model
model = ExponentialSmoothing(
    train["Value"],
    trend="add",
    seasonal="add",
    seasonal_periods=12,
    initialization_method="estimated"
)
fit = model.fit()
y_smooth = fit.fittedvalues

# Step 6: Residual ACF plot
residuals = train["Value"] - y_smooth
plot_acf(residuals, lags=30)
plt.title("Residual ACF - Holt-Winters Model (EAFV)")
plt.tight_layout()
plt.show()

# Step 7: Forecast from Jan 2024 to Dec 2025
forecast_start = pd.to_datetime("2024-01-01")
forecast_end = pd.to_datetime("2025-12-01")
forecast_steps = (forecast_end.year - forecast_start.year) * 12 + (forecast_end.month - forecast_start.month) + 1

forecast = fit.forecast(steps=forecast_steps)
forecast.index = pd.date_range(start=forecast_start, periods=forecast_steps, freq="MS")

# Step 8: Plot
plt.figure(figsize=(12, 6))
plt.plot(df.index, df["Value"], label="Observed", color="black")  # 原始观测值不变
plt.plot(y_smooth.index, y_smooth, label="Fitted", linestyle="--", color="orange")  # 用清洗数据拟合的曲线

# 衔接蓝色预测曲线
combined_index = [y_smooth.index[-1]] + list(forecast.index)
combined_values = [y_smooth.iloc[-1]] + list(forecast.values)
plt.plot(combined_index, combined_values, label="Forecast (2024–2025)", color="blue")

plt.title("Holt-Winters Forecast - EAFV ")
plt.xlabel("Date")
plt.ylabel("Index Value")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# Step 9: Print model evaluation
mse = mean_squared_error(train["Value"], y_smooth)
rmse = np.sqrt(mse)
mae = mean_absolute_error(train["Value"], y_smooth)
mape = np.mean(np.abs((train["Value"] - y_smooth) / train["Value"])) * 100

print("Model Evaluation on Training Set:")
print(f"MSE:  {mse:.2f}")
print(f"RMSE: {rmse:.2f}")
print(f"MAE:  {mae:.2f}")
print(f"MAPE: {mape:.2f}%")
