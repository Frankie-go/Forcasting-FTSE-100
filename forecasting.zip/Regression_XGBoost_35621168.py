# -*- coding: utf-8 -*-
"""
Description: This script applies XGBoost regression to predict FTSE index using economic indicators.
Includes:
- Data preprocessing
- Feature scaling
- XGBoost training and evaluation (train-test split)
- Model comparison (Linear, Ridge, Lasso, XGBoost)
- Multicollinearity check (VIF)
- Future value forecasting
- Visualizations: Forecast, Feature importance, Model comparison table
"""

import matplotlib
matplotlib.use('TkAgg')  # Use 'Agg' if no GUI support is available

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, RidgeCV, LassoCV
from statsmodels.stats.outliers_influence import variance_inflation_factor
from xgboost import XGBRegressor

# Step 1: Load and preprocess data
df = pd.read_excel("regressionData35621168.xlsx")
df.columns = df.columns.str.strip()
df['Date'] = pd.to_datetime(df['Date'], format='%Y %b')
df = df[(df['Date'] >= '2001-02-01') & (df['Date'] <= '2024-02-01')]
df = df.set_index('Date')

X_raw = df[['K54D', 'JQ2J', 'K226', 'EAFV']]
y = df['Price']

# Step 2: Feature Scaling (for XGBoost)
scaler = StandardScaler()
X_scaled = pd.DataFrame(scaler.fit_transform(X_raw), columns=X_raw.columns, index=X_raw.index)

# Step 3: Train/Test Split for proper evaluation
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Step 4: Fit XGBoost model and evaluate
model = XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42, verbosity=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Step 4.1: Print evaluation metrics
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_test, y_pred)
mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100
r2 = r2_score(y_test, y_pred)

print("XGBoost Test Performance:")
print(f"R²: {r2:.4f}")
print(f"MSE: {mse:.2f}")
print(f"RMSE: {rmse:.2f}")
print(f"MAE: {mae:.2f}")
print(f"MAPE: {mape:.2f}%")

# Step 4.5: Compare with other regression models and plot performance table
models = {
    "Linear Regression": LinearRegression(),
    "Ridge Regression": RidgeCV(alphas=np.logspace(-3, 3, 100), cv=5),
    "Lasso Regression": LassoCV(alphas=np.logspace(-3, 3, 100), cv=5, max_iter=10000),
    "XGBoost": XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42, verbosity=0)
}

results = []
for name, model_temp in models.items():
    model_temp.fit(X_train, y_train)
    y_pred_temp = model_temp.predict(X_test)
    mse_temp = mean_squared_error(y_test, y_pred_temp)
    rmse_temp = np.sqrt(mse_temp)
    mae_temp = mean_absolute_error(y_test, y_pred_temp)
    mape_temp = np.mean(np.abs((y_test - y_pred_temp) / y_test)) * 100
    r2_temp = r2_score(y_test, y_pred_temp)
    results.append({
        "Model": name,
        "R²": r2_temp,
        "MSE": mse_temp,
        "RMSE": rmse_temp,
        "MAE": mae_temp,
        "MAPE (%)": mape_temp
    })

results_df = pd.DataFrame(results)

# Plot model performance table
fig, ax = plt.subplots(figsize=(10, 3))
ax.axis('off')
ax.axis('tight')
table = ax.table(
    cellText=np.round(results_df.iloc[:, 1:].values, 2),
    colLabels=results_df.columns[1:],
    rowLabels=results_df["Model"],
    cellLoc='center',
    loc='center'
)
table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1.2, 1.8)
plt.title("Model Performance Comparison", fontsize=13)
plt.tight_layout()
plt.savefig("model_performance_comparison.png")
plt.show()

# Step 5: Calculate VIF to check multicollinearity
X_vif = X_raw.copy()
X_vif['Intercept'] = 1
vif = pd.DataFrame({
    "Variable": X_vif.columns,
    "VIF": [variance_inflation_factor(X_vif.values, i) for i in range(X_vif.shape[1])]
})
print("\nVIF Table:\n", vif)

# Step 6: Forecast future FTSE values (2024-03 to 2025-12)
future_months = pd.date_range(start='2024-03-01', end='2025-12-01', freq='MS')
last_row = X_raw.iloc[-1:]
last_scaled = scaler.transform(last_row)
future_scaled = pd.DataFrame([last_scaled[0]] * len(future_months), columns=X_raw.columns, index=future_months)
future_preds = model.predict(future_scaled)

# Step 7: Plot observed, fitted, and forecasted values
y_full_fit = model.predict(X_scaled)

plt.figure(figsize=(12, 6))
sns.lineplot(x=df.index, y=y, label="Observed", color="#1f77b4", linewidth=2)
sns.lineplot(x=df.index, y=y_full_fit, label="Fitted (All Data)", color="#1f77b4", linestyle='--', linewidth=1.5)
sns.lineplot(x=future_months, y=future_preds, label="Forecast (2025)", color="#d62728", linewidth=2)

plt.title("FTSE Forecast Using XGBoost Regression", fontsize=14)
plt.xlabel("Date")
plt.ylabel("FTSE Index")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("forecast_plot.png")
plt.show()

# Step 8: Plot feature importance
plt.figure(figsize=(8, 5))
importance = model.feature_importances_
sns.barplot(
    x=importance,
    y=X_raw.columns,
    color="#1f77b4",
    hue=None,
    legend=False
)
plt.title("Feature Importance from XGBoost")
plt.xlabel("Importance")
plt.ylabel("Features")
plt.tight_layout()
plt.savefig("feature_importance.png")
plt.show()
