#  SARIMA forecasting to K54D data.
# Steps:
# 1. Import necessary libraries
# 2. Load and preprocess the data
# 3. Stationarity test using ADF
# 4. Auto ARIMA for (p,d,q)(P,D,Q,s) parameter selection
# 5. Fit SARIMA model
# 6. Diagnose residuals
# 7. Forecast for 2025
# 8. Plot observed vs forecasted
# 9. Evaluate model accuracy

# ================================
# 1. Import necessary libraries
# ================================
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller
from sklearn.metrics import mean_squared_error, mean_absolute_error
from pmdarima import auto_arima
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.graphics.gofplots import qqplot
import seaborn as sns

# ================================
# 2. Load and preprocess the data
# ================================
df = pd.read_excel("K54DData35621168.xlsx")
df.columns = ["Date", "Value"]
df["Date"] = pd.to_datetime(df["Date"], format="%Y %b", errors="coerce")
df["Value"] = pd.to_numeric(df["Value"], errors="coerce")
df = df.dropna().set_index("Date").asfreq("MS")

# ================================
# 3. ADF stationarity tests
# ================================
def adf_test(series, title=""):
    print(f"\nADF Test – {title}")
    result = adfuller(series.dropna())
    print("ADF Statistic:", result[0])
    print("p-value:", result[1])
    print("Critical Values:", result[4])

adf_test(df["Value"], title="Original Series")
df_diff = df.diff(12).dropna()
adf_test(df_diff["Value"], title="Seasonal Difference")
df_diff2 = df_diff.diff().dropna()
adf_test(df_diff2["Value"], title="Seasonal + First Difference")

# ================================
# 4. Auto ARIMA for parameter tuning
# ================================
print("\n🔍 Running auto_arima for optimal parameters...")
auto_model = auto_arima(df["Value"],
                        seasonal=True,
                        m=12,
                        stepwise=True,
                        trace=True,
                        suppress_warnings=True,
                        error_action='ignore',
                        max_order=10)

print("\nAuto ARIMA Selected Order:")
print(f"Non-seasonal: {auto_model.order}, Seasonal: {auto_model.seasonal_order}")

# Extract best parameters
order = auto_model.order
seasonal_order = auto_model.seasonal_order

# ================================0
# 5. Fit SARIMA model using best parameters
# ================================
model = sm.tsa.statespace.SARIMAX(
    df["Value"],
    order=order,
    seasonal_order=seasonal_order,
    enforce_stationarity=False,
    enforce_invertibility=False
)
res = model.fit()
print(res.summary())

# ================================
# 6. Residual diagnostics
# ================================
resid = res.resid
fig, axs = plt.subplots(2, 2, figsize=(12, 8))

axs[0, 0].plot(resid)
axs[0, 0].axhline(0, ls="--", color="gray")
axs[0, 0].set_title("Standardized Residuals")

sns.histplot(resid, kde=True, stat="density", bins=20, ax=axs[0, 1])
axs[0, 1].set_title("Histogram + KDE")

qqplot(resid, line='s', ax=axs[1, 0])
axs[1, 0].set_title("Normal Q-Q Plot")

plot_acf(resid, lags=20, ax=axs[1, 1])
axs[1, 1].set_title("Residual ACF")

plt.tight_layout()
plt.show()

# ================================
# 7. Forecast for 2025
# ================================
forecast = res.get_forecast(steps=12)
mean = forecast.predicted_mean
ci = forecast.conf_int()

# ================================
# 8. Plot observed vs forecasted
# ================================
plt.figure(figsize=(12, 6))
plt.plot(df["Value"], label="Observed", color="#1f77b4", linewidth=2)
plt.plot(mean, label="SARIMA Forecast (2025)", color="#d62728", linewidth=2)
plt.fill_between(ci.index, ci.iloc[:, 0], ci.iloc[:, 1], color="pink", alpha=0.3)
plt.title("K54D Turnover Forecast Using Auto-SARIMA", fontsize=14)
plt.xlabel("Date")
plt.ylabel("Turnover (£ Million)")
plt.grid(True, linestyle="--", alpha=0.3)
plt.legend()
plt.tight_layout()
plt.show()

# ================================
# 9. Model Evaluation
# ================================
pred = res.get_prediction(start=df.index[0])
pred_mean = pred.predicted_mean
true = df["Value"]

mse = mean_squared_error(true, pred_mean)
rmse = np.sqrt(mse)
mae = mean_absolute_error(true, pred_mean)
mape = np.mean(np.abs((true - pred_mean) / true)) * 100

print("\n📊 Model Evaluation:")
print(f"MSE  : {mse:.2f}")
print(f"RMSE : {rmse:.2f}")
print(f"MAE  : {mae:.2f}")
print(f"MAPE : {mape:.2f}%")
